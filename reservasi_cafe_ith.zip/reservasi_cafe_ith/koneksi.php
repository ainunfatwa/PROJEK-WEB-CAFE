<?php
$koneksi = mysqli_connect("localhost","root","","reservasi_cafe") or die ('database tidak terhubung');
?>