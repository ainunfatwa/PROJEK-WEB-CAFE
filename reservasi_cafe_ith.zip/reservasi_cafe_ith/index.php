<?php
session_start();
if(!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>RESERVASI CAFE ITH</title>
</head>
<body style="text-align:center">
    <h1>Halaman ITH Cafe</h1>
    <a href="index.php">Home</a>
    <a href="logout.php">Logout</a>
    <hr>
    <h3>Selamat Datang, <?php echo $_SESSION['user']['nama']; ?></h3>
    <p>Halaman ini akan tampil setelah user login.</p>
</body>
</html>
